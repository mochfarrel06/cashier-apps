@extends('auth.master')

@section('content')
    <h1>Login</h1>
@endsection

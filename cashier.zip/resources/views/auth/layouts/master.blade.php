<!DOCTYPE html>
<html lang="en">

<head>

    @include('auth.layouts.head')

</head>

<body style="background-color: #722c75">

    @yield('content')

    @include('auth.layouts.scripts')

</body>

</html>

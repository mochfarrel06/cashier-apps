@props(['image'])

<div class="d-flex justify-content-center">
    <img src="{{ $image }}" alt="logo" class="shadow-light rounded-circle img-fluid" style="max-width: 100px;">
</div>

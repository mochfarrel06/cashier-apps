@props(['description'])

<div class="text-center mt-5">
    <p class="small text-dark">{{ $description }}</p>
</div>

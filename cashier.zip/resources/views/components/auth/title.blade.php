@props(['title'])

<div class="text-center mt-3">
    <h4 class="text-gray-900 mb-4">{{ $title }}</h4>
</div>

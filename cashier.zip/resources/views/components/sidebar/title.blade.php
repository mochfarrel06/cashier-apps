<a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route($addRoute) }}">
    <div class="sidebar-brand-icon rotate-n-15">
        <i class="{{ $icon }}"></i>
    </div>
    <div class="sidebar-brand-text mx-3">{{ $name }}</div>
</a>

<hr class="sidebar-divider my-0">

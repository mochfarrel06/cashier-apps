<div class="row mb-4">
    {{ $slot }}
</div>

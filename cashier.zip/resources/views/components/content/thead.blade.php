<thead>
    <tr>
        @foreach ($items as $item)
            <th>{{ $item }}</th>
        @endforeach
    </tr>
</thead>

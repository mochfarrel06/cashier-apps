<div class="card shadow mb-4">
    {{ $slot }}
</div>

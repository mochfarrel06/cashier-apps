<div class="container-fluid mb-5">
    {{ $slot }}
</div>

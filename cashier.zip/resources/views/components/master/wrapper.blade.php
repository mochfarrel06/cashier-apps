<div id="wrapper">
    {{ $slot }}
</div>

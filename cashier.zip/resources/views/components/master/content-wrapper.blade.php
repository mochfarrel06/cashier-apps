<div id="content-wrapper" class="d-flex flex-column">
    {{ $slot }}
</div>

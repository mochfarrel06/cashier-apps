<div id="content">
    {{ $slot }}
</div>
